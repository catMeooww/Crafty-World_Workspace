
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.utp.item.SpawnPowderItem;
import net.mcreator.utp.item.SolidFlameItem;
import net.mcreator.utp.item.LeafParachuteItem;
import net.mcreator.utp.item.HyperGenSurfaceItem;
import net.mcreator.utp.item.HyperGenDragonItem;
import net.mcreator.utp.item.HugeLeafItem;
import net.mcreator.utp.item.FlamethrowerItem;
import net.mcreator.utp.item.EnergyCoreItem;
import net.mcreator.utp.item.DrawerKeyItem;
import net.mcreator.utp.item.CrystalFragmentOrangeItem;
import net.mcreator.utp.item.CrystalFragmentBlueItem;
import net.mcreator.utp.UtpMod;

public class UtpModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, UtpMod.MODID);
	public static final RegistryObject<Item> DRAGON_BRICKS = block(UtpModBlocks.DRAGON_BRICKS);
	public static final RegistryObject<Item> DRAGON_BRICKS_CHISELED = block(UtpModBlocks.DRAGON_BRICKS_CHISELED);
	public static final RegistryObject<Item> DRAGON_DOOR = block(UtpModBlocks.DRAGON_DOOR);
	public static final RegistryObject<Item> REDSTONIZED_DRAGON_BRICKS = block(UtpModBlocks.REDSTONIZED_DRAGON_BRICKS);
	public static final RegistryObject<Item> FIRE_PEDESTAL = block(UtpModBlocks.FIRE_PEDESTAL);
	public static final RegistryObject<Item> DRAGON_BRICKS_STAIR = block(UtpModBlocks.DRAGON_BRICKS_STAIR);
	public static final RegistryObject<Item> DRAGON_BRICKS_SLAB = block(UtpModBlocks.DRAGON_BRICKS_SLAB);
	public static final RegistryObject<Item> DRAGON_BRICKS_WALL = block(UtpModBlocks.DRAGON_BRICKS_WALL);
	public static final RegistryObject<Item> DRAGON_FIRE_ROD = block(UtpModBlocks.DRAGON_FIRE_ROD);
	public static final RegistryObject<Item> DRAGON_WOOD_WOOD = block(UtpModBlocks.DRAGON_WOOD_WOOD);
	public static final RegistryObject<Item> DRAGON_WOOD_LOG = block(UtpModBlocks.DRAGON_WOOD_LOG);
	public static final RegistryObject<Item> DRAGON_WOOD_PLANKS = block(UtpModBlocks.DRAGON_WOOD_PLANKS);
	public static final RegistryObject<Item> DRAGON_WOOD_LEAVES = block(UtpModBlocks.DRAGON_WOOD_LEAVES);
	public static final RegistryObject<Item> DRAGON_WOOD_STAIRS = block(UtpModBlocks.DRAGON_WOOD_STAIRS);
	public static final RegistryObject<Item> DRAGON_WOOD_SLAB = block(UtpModBlocks.DRAGON_WOOD_SLAB);
	public static final RegistryObject<Item> DRAGON_WOOD_FENCE = block(UtpModBlocks.DRAGON_WOOD_FENCE);
	public static final RegistryObject<Item> DRAGON_WOOD_FENCE_GATE = block(UtpModBlocks.DRAGON_WOOD_FENCE_GATE);
	public static final RegistryObject<Item> DRAGON_WOOD_PRESSURE_PLATE = block(UtpModBlocks.DRAGON_WOOD_PRESSURE_PLATE);
	public static final RegistryObject<Item> DRAGON_WOOD_BUTTON = block(UtpModBlocks.DRAGON_WOOD_BUTTON);
	public static final RegistryObject<Item> BERRIES_DRAGON_WOOD_LEAVES = block(UtpModBlocks.BERRIES_DRAGON_WOOD_LEAVES);
	public static final RegistryObject<Item> DRAGON_LOOT_GENERATOR = block(UtpModBlocks.DRAGON_LOOT_GENERATOR);
	public static final RegistryObject<Item> HYPER_GEN_DRAGON = REGISTRY.register("hyper_gen_dragon", () -> new HyperGenDragonItem());
	public static final RegistryObject<Item> HYPER_CRYSTAL_DRAGON = block(UtpModBlocks.HYPER_CRYSTAL_DRAGON);
	public static final RegistryObject<Item> DUNGEON_LOOT_GENERATOR = block(UtpModBlocks.DUNGEON_LOOT_GENERATOR);
	public static final RegistryObject<Item> HYPER_GEN_SURFACE = REGISTRY.register("hyper_gen_surface", () -> new HyperGenSurfaceItem());
	public static final RegistryObject<Item> HYPER_CRYSTAL_SURFACE = block(UtpModBlocks.HYPER_CRYSTAL_SURFACE);
	public static final RegistryObject<Item> FLAMETHROWER = REGISTRY.register("flamethrower", () -> new FlamethrowerItem());
	public static final RegistryObject<Item> DRAGON_TNT = block(UtpModBlocks.DRAGON_TNT);
	public static final RegistryObject<Item> SOLID_FLAME = REGISTRY.register("solid_flame", () -> new SolidFlameItem());
	public static final RegistryObject<Item> ORANGE_CRYSTAL = block(UtpModBlocks.ORANGE_CRYSTAL);
	public static final RegistryObject<Item> BLUE_CRYSTAL = block(UtpModBlocks.BLUE_CRYSTAL);
	public static final RegistryObject<Item> ACTIVED_ORANGE_CRYSTAL = block(UtpModBlocks.ACTIVED_ORANGE_CRYSTAL);
	public static final RegistryObject<Item> ACTIVED_BLUE_CRYSTAL = block(UtpModBlocks.ACTIVED_BLUE_CRYSTAL);
	public static final RegistryObject<Item> ORANGE_CRYSTAL_ENERGIC = block(UtpModBlocks.ORANGE_CRYSTAL_ENERGIC);
	public static final RegistryObject<Item> BLUE_CRYSTAL_ENERGIC = block(UtpModBlocks.BLUE_CRYSTAL_ENERGIC);
	public static final RegistryObject<Item> ACTIVED_ORANGE_CRYSTAL_ENERGIC = block(UtpModBlocks.ACTIVED_ORANGE_CRYSTAL_ENERGIC);
	public static final RegistryObject<Item> ACTIVED_BLUE_CRYSTAL_ENERGIC = block(UtpModBlocks.ACTIVED_BLUE_CRYSTAL_ENERGIC);
	public static final RegistryObject<Item> CRYSTAL_FRAGMENT_ORANGE = REGISTRY.register("crystal_fragment_orange", () -> new CrystalFragmentOrangeItem());
	public static final RegistryObject<Item> CRYSTAL_FRAGMENT_BLUE = REGISTRY.register("crystal_fragment_blue", () -> new CrystalFragmentBlueItem());
	public static final RegistryObject<Item> SPAWN_POWDER = REGISTRY.register("spawn_powder", () -> new SpawnPowderItem());
	public static final RegistryObject<Item> CAVE_STONE = block(UtpModBlocks.CAVE_STONE);
	public static final RegistryObject<Item> CRYSTALIC_CAVE_STONE = block(UtpModBlocks.CRYSTALIC_CAVE_STONE);
	public static final RegistryObject<Item> CRYSTALIC_CAVE_STONE_ON = block(UtpModBlocks.CRYSTALIC_CAVE_STONE_ON);
	public static final RegistryObject<Item> CUSTOM_CRYSTALIC_RECEIVER = block(UtpModBlocks.CUSTOM_CRYSTALIC_RECEIVER);
	public static final RegistryObject<Item> ACTIVED_CUSTOM_CRYSTALIC_RECEIVER = block(UtpModBlocks.ACTIVED_CUSTOM_CRYSTALIC_RECEIVER);
	public static final RegistryObject<Item> CUSTOM_CRYSTALIC_SENDER = block(UtpModBlocks.CUSTOM_CRYSTALIC_SENDER);
	public static final RegistryObject<Item> DRAGON_IGNITER = block(UtpModBlocks.DRAGON_IGNITER);
	public static final RegistryObject<Item> DRAGON_STEEL_BLOCK = block(UtpModBlocks.DRAGON_STEEL_BLOCK);
	public static final RegistryObject<Item> CUT_DRAGON_STEEL_BLOCK = block(UtpModBlocks.CUT_DRAGON_STEEL_BLOCK);
	public static final RegistryObject<Item> DRAGON_STEEL_BARS = block(UtpModBlocks.DRAGON_STEEL_BARS);
	public static final RegistryObject<Item> DRAGON_STEEL_PILLARS = block(UtpModBlocks.DRAGON_STEEL_PILLARS);
	public static final RegistryObject<Item> ANDESITE_STONE_BRICKS = block(UtpModBlocks.ANDESITE_STONE_BRICKS);
	public static final RegistryObject<Item> ANDESITE_STONE_PILLARS = block(UtpModBlocks.ANDESITE_STONE_PILLARS);
	public static final RegistryObject<Item> CRACKED_ANDESITE_STONE_PILLARS = block(UtpModBlocks.CRACKED_ANDESITE_STONE_PILLARS);
	public static final RegistryObject<Item> CRYSTALIC_TABLE = block(UtpModBlocks.CRYSTALIC_TABLE);
	public static final RegistryObject<Item> WET_MOSSY_STONE = block(UtpModBlocks.WET_MOSSY_STONE);
	public static final RegistryObject<Item> WET_VINES = block(UtpModBlocks.WET_VINES);
	public static final RegistryObject<Item> LOST_LOOT_GENERATOR = block(UtpModBlocks.LOST_LOOT_GENERATOR);
	public static final RegistryObject<Item> DEAD_LIGHT = block(UtpModBlocks.DEAD_LIGHT);
	public static final RegistryObject<Item> UNSTABLE_ROCK = block(UtpModBlocks.UNSTABLE_ROCK);
	public static final RegistryObject<Item> FALLING_UNSTABLE_ROCK = block(UtpModBlocks.FALLING_UNSTABLE_ROCK);
	public static final RegistryObject<Item> RUSTY_BARS = block(UtpModBlocks.RUSTY_BARS);
	public static final RegistryObject<Item> CRACKED_GLASS = block(UtpModBlocks.CRACKED_GLASS);
	public static final RegistryObject<Item> METAL_BLOCK = block(UtpModBlocks.METAL_BLOCK);
	public static final RegistryObject<Item> CORE_FRAME = block(UtpModBlocks.CORE_FRAME);
	public static final RegistryObject<Item> OLD_SYSTEM_CONTROLER = block(UtpModBlocks.OLD_SYSTEM_CONTROLER);
	public static final RegistryObject<Item> MALFUNCTION_LAMP = block(UtpModBlocks.MALFUNCTION_LAMP);
	public static final RegistryObject<Item> MALFUNCTION_LAMP_ON = block(UtpModBlocks.MALFUNCTION_LAMP_ON);
	public static final RegistryObject<Item> WET_CONCRETE = block(UtpModBlocks.WET_CONCRETE);
	public static final RegistryObject<Item> GLASS_DOOR = block(UtpModBlocks.GLASS_DOOR);
	public static final RegistryObject<Item> OPEN_GLASS_DOOR = block(UtpModBlocks.OPEN_GLASS_DOOR);
	public static final RegistryObject<Item> SYSTEM_CONTROLLER_ON = block(UtpModBlocks.SYSTEM_CONTROLLER_ON);
	public static final RegistryObject<Item> CORE_FRAME_INSERTED = block(UtpModBlocks.CORE_FRAME_INSERTED);
	public static final RegistryObject<Item> ENERGY_CORE = REGISTRY.register("energy_core", () -> new EnergyCoreItem());
	public static final RegistryObject<Item> CAT_RUNE = block(UtpModBlocks.CAT_RUNE);
	public static final RegistryObject<Item> OLD_TECHNICAL_GLASS = block(UtpModBlocks.OLD_TECHNICAL_GLASS);
	public static final RegistryObject<Item> TECHNICAL_GLASS_ON = block(UtpModBlocks.TECHNICAL_GLASS_ON);
	public static final RegistryObject<Item> TECHNICAL_GLASS_GLITCH = block(UtpModBlocks.TECHNICAL_GLASS_GLITCH);
	public static final RegistryObject<Item> GEO_SENSOR = block(UtpModBlocks.GEO_SENSOR);
	public static final RegistryObject<Item> GEO_SENSOR_ON = block(UtpModBlocks.GEO_SENSOR_ON);
	public static final RegistryObject<Item> DRAWERS = block(UtpModBlocks.DRAWERS);
	public static final RegistryObject<Item> LOCKED_DRAWERS = block(UtpModBlocks.LOCKED_DRAWERS);
	public static final RegistryObject<Item> DRAWER_KEY = REGISTRY.register("drawer_key", () -> new DrawerKeyItem());
	public static final RegistryObject<Item> EXPLORER_WORKSTATION = block(UtpModBlocks.EXPLORER_WORKSTATION);
	public static final RegistryObject<Item> FIRST_TOWER_CORE = block(UtpModBlocks.FIRST_TOWER_CORE);
	public static final RegistryObject<Item> FIRST_TOWER_CORE_ON = block(UtpModBlocks.FIRST_TOWER_CORE_ON);
	public static final RegistryObject<Item> MAGNETIC_ROCK = block(UtpModBlocks.MAGNETIC_ROCK);
	public static final RegistryObject<Item> WEAK_MAGNETIC_ROCK = block(UtpModBlocks.WEAK_MAGNETIC_ROCK);
	public static final RegistryObject<Item> BROKEN_MAGNETIC_ROCK = block(UtpModBlocks.BROKEN_MAGNETIC_ROCK);
	public static final RegistryObject<Item> HARD_TREE_LOG = block(UtpModBlocks.HARD_TREE_LOG);
	public static final RegistryObject<Item> HARD_TREE_LEAVES = block(UtpModBlocks.HARD_TREE_LEAVES);
	public static final RegistryObject<Item> HUGE_LEAF = REGISTRY.register("huge_leaf", () -> new HugeLeafItem());
	public static final RegistryObject<Item> LEAF_PARACHUTE = REGISTRY.register("leaf_parachute", () -> new LeafParachuteItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
