
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utp.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.utp.client.particle.SmallMagneticRocksPiecesParticle;
import net.mcreator.utp.client.particle.MagneticRocksPiecesParticle;
import net.mcreator.utp.client.particle.LeafnessParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class UtpModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(UtpModParticleTypes.SMALL_MAGNETIC_ROCKS_PIECES.get(), SmallMagneticRocksPiecesParticle::provider);
		event.registerSpriteSet(UtpModParticleTypes.MAGNETIC_ROCKS_PIECES.get(), MagneticRocksPiecesParticle::provider);
		event.registerSpriteSet(UtpModParticleTypes.LEAFNESS.get(), LeafnessParticle::provider);
	}
}
