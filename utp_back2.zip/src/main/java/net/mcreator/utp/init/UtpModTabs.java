
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.utp.UtpMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class UtpModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, UtpMod.MODID);
	public static final RegistryObject<CreativeModeTab> UTP_TAB = REGISTRY.register("utp_tab",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.utp.utp_tab")).icon(() -> new ItemStack(UtpModBlocks.DRAGON_BRICKS_CHISELED.get())).displayItems((parameters, tabData) -> {
				tabData.accept(UtpModBlocks.DRAGON_BRICKS.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_BRICKS_CHISELED.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_DOOR.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_BRICKS_STAIR.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_BRICKS_SLAB.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_BRICKS_WALL.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_LOOT_GENERATOR.get().asItem());
				tabData.accept(UtpModBlocks.REDSTONIZED_DRAGON_BRICKS.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_STEEL_BLOCK.get().asItem());
				tabData.accept(UtpModBlocks.CUT_DRAGON_STEEL_BLOCK.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_STEEL_PILLARS.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_STEEL_BARS.get().asItem());
				tabData.accept(UtpModBlocks.FIRE_PEDESTAL.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_FIRE_ROD.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_IGNITER.get().asItem());
				tabData.accept(UtpModItems.FLAMETHROWER.get());
				tabData.accept(UtpModBlocks.DRAGON_TNT.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_WOOD.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_LOG.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_PLANKS.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_LEAVES.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_STAIRS.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_SLAB.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_FENCE.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_FENCE_GATE.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_PRESSURE_PLATE.get().asItem());
				tabData.accept(UtpModBlocks.DRAGON_WOOD_BUTTON.get().asItem());
				tabData.accept(UtpModItems.HYPER_GEN_DRAGON.get());
				tabData.accept(UtpModBlocks.HYPER_CRYSTAL_DRAGON.get().asItem());
				tabData.accept(UtpModBlocks.DUNGEON_LOOT_GENERATOR.get().asItem());
				tabData.accept(UtpModItems.SPAWN_POWDER.get());
				tabData.accept(UtpModItems.HYPER_GEN_SURFACE.get());
				tabData.accept(UtpModBlocks.HYPER_CRYSTAL_SURFACE.get().asItem());
				tabData.accept(UtpModBlocks.ORANGE_CRYSTAL.get().asItem());
				tabData.accept(UtpModBlocks.BLUE_CRYSTAL.get().asItem());
				tabData.accept(UtpModBlocks.ORANGE_CRYSTAL_ENERGIC.get().asItem());
				tabData.accept(UtpModBlocks.BLUE_CRYSTAL_ENERGIC.get().asItem());
				tabData.accept(UtpModItems.CRYSTAL_FRAGMENT_ORANGE.get());
				tabData.accept(UtpModItems.CRYSTAL_FRAGMENT_BLUE.get());
				tabData.accept(UtpModBlocks.CAVE_STONE.get().asItem());
				tabData.accept(UtpModBlocks.CRYSTALIC_CAVE_STONE.get().asItem());
				tabData.accept(UtpModBlocks.CUSTOM_CRYSTALIC_RECEIVER.get().asItem());
				tabData.accept(UtpModBlocks.CUSTOM_CRYSTALIC_SENDER.get().asItem());
				tabData.accept(UtpModBlocks.ANDESITE_STONE_BRICKS.get().asItem());
				tabData.accept(UtpModBlocks.ANDESITE_STONE_PILLARS.get().asItem());
				tabData.accept(UtpModBlocks.CRACKED_ANDESITE_STONE_PILLARS.get().asItem());
				tabData.accept(UtpModBlocks.CRYSTALIC_TABLE.get().asItem());
				tabData.accept(UtpModBlocks.LOST_LOOT_GENERATOR.get().asItem());
				tabData.accept(UtpModBlocks.DEAD_LIGHT.get().asItem());
				tabData.accept(UtpModBlocks.UNSTABLE_ROCK.get().asItem());
				tabData.accept(UtpModBlocks.METAL_BLOCK.get().asItem());
				tabData.accept(UtpModBlocks.CORE_FRAME.get().asItem());
				tabData.accept(UtpModBlocks.OLD_SYSTEM_CONTROLER.get().asItem());
				tabData.accept(UtpModBlocks.MALFUNCTION_LAMP.get().asItem());
				tabData.accept(UtpModBlocks.GLASS_DOOR.get().asItem());
				tabData.accept(UtpModItems.ENERGY_CORE.get());
				tabData.accept(UtpModBlocks.CAT_RUNE.get().asItem());
				tabData.accept(UtpModBlocks.OLD_TECHNICAL_GLASS.get().asItem());
				tabData.accept(UtpModBlocks.GEO_SENSOR.get().asItem());
				tabData.accept(UtpModBlocks.DRAWERS.get().asItem());
				tabData.accept(UtpModItems.DRAWER_KEY.get());
				tabData.accept(UtpModBlocks.EXPLORER_WORKSTATION.get().asItem());
				tabData.accept(UtpModBlocks.FIRST_TOWER_CORE.get().asItem());
				tabData.accept(UtpModBlocks.MAGNETIC_ROCK.get().asItem());
				tabData.accept(UtpModBlocks.WEAK_MAGNETIC_ROCK.get().asItem());
				tabData.accept(UtpModBlocks.HARD_TREE_LOG.get().asItem());
				tabData.accept(UtpModBlocks.HARD_TREE_LEAVES.get().asItem());
				tabData.accept(UtpModItems.HUGE_LEAF.get());
				tabData.accept(UtpModItems.LEAF_PARACHUTE.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.OP_BLOCKS) {
			if (tabData.hasPermissions()) {
				tabData.accept(UtpModBlocks.WET_MOSSY_STONE.get().asItem());
				tabData.accept(UtpModBlocks.WET_CONCRETE.get().asItem());
			}
		} else if (tabData.getTabKey() == CreativeModeTabs.NATURAL_BLOCKS) {
			tabData.accept(UtpModBlocks.WET_VINES.get().asItem());
		} else if (tabData.getTabKey() == CreativeModeTabs.BUILDING_BLOCKS) {
			tabData.accept(UtpModBlocks.RUSTY_BARS.get().asItem());
			tabData.accept(UtpModBlocks.CRACKED_GLASS.get().asItem());
		}
	}
}
