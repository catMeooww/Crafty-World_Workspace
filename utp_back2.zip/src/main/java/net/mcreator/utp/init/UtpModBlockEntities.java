
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;

import net.mcreator.utp.block.entity.ExplorerWorkstationBlockEntity;
import net.mcreator.utp.block.entity.DrawersBlockEntity;
import net.mcreator.utp.block.entity.DragonDoorBlockEntity;
import net.mcreator.utp.block.entity.CustomCrystalicSenderBlockEntity;
import net.mcreator.utp.block.entity.CustomCrystalicReceiverBlockEntity;
import net.mcreator.utp.block.entity.CrystalicTableBlockEntity;
import net.mcreator.utp.block.entity.ActivedCustomCrystalicReceiverBlockEntity;
import net.mcreator.utp.UtpMod;

public class UtpModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, UtpMod.MODID);
	public static final RegistryObject<BlockEntityType<?>> DRAGON_DOOR = register("dragon_door", UtpModBlocks.DRAGON_DOOR, DragonDoorBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CUSTOM_CRYSTALIC_RECEIVER = register("custom_crystalic_receiver", UtpModBlocks.CUSTOM_CRYSTALIC_RECEIVER, CustomCrystalicReceiverBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> ACTIVED_CUSTOM_CRYSTALIC_RECEIVER = register("actived_custom_crystalic_receiver", UtpModBlocks.ACTIVED_CUSTOM_CRYSTALIC_RECEIVER, ActivedCustomCrystalicReceiverBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CUSTOM_CRYSTALIC_SENDER = register("custom_crystalic_sender", UtpModBlocks.CUSTOM_CRYSTALIC_SENDER, CustomCrystalicSenderBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> CRYSTALIC_TABLE = register("crystalic_table", UtpModBlocks.CRYSTALIC_TABLE, CrystalicTableBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> DRAWERS = register("drawers", UtpModBlocks.DRAWERS, DrawersBlockEntity::new);
	public static final RegistryObject<BlockEntityType<?>> EXPLORER_WORKSTATION = register("explorer_workstation", UtpModBlocks.EXPLORER_WORKSTATION, ExplorerWorkstationBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static RegistryObject<BlockEntityType<?>> register(String registryname, RegistryObject<Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> BlockEntityType.Builder.of(supplier, block.get()).build(null));
	}
}
