
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utp.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.utp.client.gui.LootContainerScreen;
import net.mcreator.utp.client.gui.CrystalicEditorScreen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class UtpModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(UtpModMenus.CRYSTALIC_EDITOR.get(), CrystalicEditorScreen::new);
			MenuScreens.register(UtpModMenus.LOOT_CONTAINER.get(), LootContainerScreen::new);
		});
	}
}
