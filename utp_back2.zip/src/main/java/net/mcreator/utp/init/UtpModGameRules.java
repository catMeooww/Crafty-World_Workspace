
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utp.init;

import net.minecraftforge.fml.common.Mod;

import net.minecraft.world.level.GameRules;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class UtpModGameRules {
	public static final GameRules.Key<GameRules.IntegerValue> CRYSTAL_RANGE = GameRules.register("crystalRange", GameRules.Category.MISC, GameRules.IntegerValue.create(40));
}
