
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.utp.block.WetVinesBlock;
import net.mcreator.utp.block.WetMossyStoneBlock;
import net.mcreator.utp.block.WetConcreteBlock;
import net.mcreator.utp.block.WeakMagneticRockBlock;
import net.mcreator.utp.block.UnstableRockBlock;
import net.mcreator.utp.block.TechnicalGlassOnBlock;
import net.mcreator.utp.block.TechnicalGlassGlitchBlock;
import net.mcreator.utp.block.SystemControllerOnBlock;
import net.mcreator.utp.block.RustyBarsBlock;
import net.mcreator.utp.block.RedstonizedDragonBricksBlock;
import net.mcreator.utp.block.OrangeCrystalEnergicBlock;
import net.mcreator.utp.block.OrangeCrystalBlock;
import net.mcreator.utp.block.OpenGlassDoorBlock;
import net.mcreator.utp.block.OldTechnicalGlassBlock;
import net.mcreator.utp.block.OldSystemControlerBlock;
import net.mcreator.utp.block.MetalBlockBlock;
import net.mcreator.utp.block.MalfunctionLampOnBlock;
import net.mcreator.utp.block.MalfunctionLampBlock;
import net.mcreator.utp.block.MagneticRockBlock;
import net.mcreator.utp.block.LostLootGeneratorBlock;
import net.mcreator.utp.block.LockedDrawersBlock;
import net.mcreator.utp.block.HyperCrystalSurfaceBlock;
import net.mcreator.utp.block.HyperCrystalDragonBlock;
import net.mcreator.utp.block.HardTreeLogBlock;
import net.mcreator.utp.block.HardTreeLeavesBlock;
import net.mcreator.utp.block.GlassDoorBlock;
import net.mcreator.utp.block.GeoSensorOnBlock;
import net.mcreator.utp.block.GeoSensorBlock;
import net.mcreator.utp.block.FirstTowerCoreOnBlock;
import net.mcreator.utp.block.FirstTowerCoreBlock;
import net.mcreator.utp.block.FirePedestalBlock;
import net.mcreator.utp.block.FallingUnstableRockBlock;
import net.mcreator.utp.block.ExplorerWorkstationBlock;
import net.mcreator.utp.block.DungeonLootGeneratorBlock;
import net.mcreator.utp.block.DrawersBlock;
import net.mcreator.utp.block.DragonWoodWoodBlock;
import net.mcreator.utp.block.DragonWoodStairsBlock;
import net.mcreator.utp.block.DragonWoodSlabBlock;
import net.mcreator.utp.block.DragonWoodPressurePlateBlock;
import net.mcreator.utp.block.DragonWoodPlanksBlock;
import net.mcreator.utp.block.DragonWoodLogBlock;
import net.mcreator.utp.block.DragonWoodLeavesBlock;
import net.mcreator.utp.block.DragonWoodFenceGateBlock;
import net.mcreator.utp.block.DragonWoodFenceBlock;
import net.mcreator.utp.block.DragonWoodButtonBlock;
import net.mcreator.utp.block.DragonTntBlock;
import net.mcreator.utp.block.DragonSteelPillarsBlock;
import net.mcreator.utp.block.DragonSteelBlockBlock;
import net.mcreator.utp.block.DragonSteelBarsBlock;
import net.mcreator.utp.block.DragonLootGeneratorBlock;
import net.mcreator.utp.block.DragonIgniterBlock;
import net.mcreator.utp.block.DragonFireRodBlock;
import net.mcreator.utp.block.DragonDoorBlock;
import net.mcreator.utp.block.DragonBricksWallBlock;
import net.mcreator.utp.block.DragonBricksStairBlock;
import net.mcreator.utp.block.DragonBricksSlabBlock;
import net.mcreator.utp.block.DragonBricksChiseledBlock;
import net.mcreator.utp.block.DragonBricksBlock;
import net.mcreator.utp.block.DeadLightBlock;
import net.mcreator.utp.block.CutDragonSteelBlockBlock;
import net.mcreator.utp.block.CustomCrystalicSenderBlock;
import net.mcreator.utp.block.CustomCrystalicReceiverBlock;
import net.mcreator.utp.block.CrystalicTableBlock;
import net.mcreator.utp.block.CrystalicCaveStoneOnBlock;
import net.mcreator.utp.block.CrystalicCaveStoneBlock;
import net.mcreator.utp.block.CrackedGlassBlock;
import net.mcreator.utp.block.CrackedAndesiteStonePillarsBlock;
import net.mcreator.utp.block.CoreFrameInsertedBlock;
import net.mcreator.utp.block.CoreFrameBlock;
import net.mcreator.utp.block.CaveStoneBlock;
import net.mcreator.utp.block.CatRuneBlock;
import net.mcreator.utp.block.BrokenMagneticRockBlock;
import net.mcreator.utp.block.BlueCrystalEnergicBlock;
import net.mcreator.utp.block.BlueCrystalBlock;
import net.mcreator.utp.block.BerriesDragonWoodLeavesBlock;
import net.mcreator.utp.block.AndesiteStonePillarsBlock;
import net.mcreator.utp.block.AndesiteStoneBricksBlock;
import net.mcreator.utp.block.ActivedOrangeCrystalEnergicBlock;
import net.mcreator.utp.block.ActivedOrangeCrystalBlock;
import net.mcreator.utp.block.ActivedCustomCrystalicReceiverBlock;
import net.mcreator.utp.block.ActivedBlueCrystalEnergicBlock;
import net.mcreator.utp.block.ActivedBlueCrystalBlock;
import net.mcreator.utp.UtpMod;

public class UtpModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, UtpMod.MODID);
	public static final RegistryObject<Block> DRAGON_BRICKS = REGISTRY.register("dragon_bricks", () -> new DragonBricksBlock());
	public static final RegistryObject<Block> DRAGON_BRICKS_CHISELED = REGISTRY.register("dragon_bricks_chiseled", () -> new DragonBricksChiseledBlock());
	public static final RegistryObject<Block> DRAGON_DOOR = REGISTRY.register("dragon_door", () -> new DragonDoorBlock());
	public static final RegistryObject<Block> REDSTONIZED_DRAGON_BRICKS = REGISTRY.register("redstonized_dragon_bricks", () -> new RedstonizedDragonBricksBlock());
	public static final RegistryObject<Block> FIRE_PEDESTAL = REGISTRY.register("fire_pedestal", () -> new FirePedestalBlock());
	public static final RegistryObject<Block> DRAGON_BRICKS_STAIR = REGISTRY.register("dragon_bricks_stair", () -> new DragonBricksStairBlock());
	public static final RegistryObject<Block> DRAGON_BRICKS_SLAB = REGISTRY.register("dragon_bricks_slab", () -> new DragonBricksSlabBlock());
	public static final RegistryObject<Block> DRAGON_BRICKS_WALL = REGISTRY.register("dragon_bricks_wall", () -> new DragonBricksWallBlock());
	public static final RegistryObject<Block> DRAGON_FIRE_ROD = REGISTRY.register("dragon_fire_rod", () -> new DragonFireRodBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_WOOD = REGISTRY.register("dragon_wood_wood", () -> new DragonWoodWoodBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_LOG = REGISTRY.register("dragon_wood_log", () -> new DragonWoodLogBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_PLANKS = REGISTRY.register("dragon_wood_planks", () -> new DragonWoodPlanksBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_LEAVES = REGISTRY.register("dragon_wood_leaves", () -> new DragonWoodLeavesBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_STAIRS = REGISTRY.register("dragon_wood_stairs", () -> new DragonWoodStairsBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_SLAB = REGISTRY.register("dragon_wood_slab", () -> new DragonWoodSlabBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_FENCE = REGISTRY.register("dragon_wood_fence", () -> new DragonWoodFenceBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_FENCE_GATE = REGISTRY.register("dragon_wood_fence_gate", () -> new DragonWoodFenceGateBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_PRESSURE_PLATE = REGISTRY.register("dragon_wood_pressure_plate", () -> new DragonWoodPressurePlateBlock());
	public static final RegistryObject<Block> DRAGON_WOOD_BUTTON = REGISTRY.register("dragon_wood_button", () -> new DragonWoodButtonBlock());
	public static final RegistryObject<Block> BERRIES_DRAGON_WOOD_LEAVES = REGISTRY.register("berries_dragon_wood_leaves", () -> new BerriesDragonWoodLeavesBlock());
	public static final RegistryObject<Block> DRAGON_LOOT_GENERATOR = REGISTRY.register("dragon_loot_generator", () -> new DragonLootGeneratorBlock());
	public static final RegistryObject<Block> HYPER_CRYSTAL_DRAGON = REGISTRY.register("hyper_crystal_dragon", () -> new HyperCrystalDragonBlock());
	public static final RegistryObject<Block> DUNGEON_LOOT_GENERATOR = REGISTRY.register("dungeon_loot_generator", () -> new DungeonLootGeneratorBlock());
	public static final RegistryObject<Block> HYPER_CRYSTAL_SURFACE = REGISTRY.register("hyper_crystal_surface", () -> new HyperCrystalSurfaceBlock());
	public static final RegistryObject<Block> DRAGON_TNT = REGISTRY.register("dragon_tnt", () -> new DragonTntBlock());
	public static final RegistryObject<Block> ORANGE_CRYSTAL = REGISTRY.register("orange_crystal", () -> new OrangeCrystalBlock());
	public static final RegistryObject<Block> BLUE_CRYSTAL = REGISTRY.register("blue_crystal", () -> new BlueCrystalBlock());
	public static final RegistryObject<Block> ACTIVED_ORANGE_CRYSTAL = REGISTRY.register("actived_orange_crystal", () -> new ActivedOrangeCrystalBlock());
	public static final RegistryObject<Block> ACTIVED_BLUE_CRYSTAL = REGISTRY.register("actived_blue_crystal", () -> new ActivedBlueCrystalBlock());
	public static final RegistryObject<Block> ORANGE_CRYSTAL_ENERGIC = REGISTRY.register("orange_crystal_energic", () -> new OrangeCrystalEnergicBlock());
	public static final RegistryObject<Block> BLUE_CRYSTAL_ENERGIC = REGISTRY.register("blue_crystal_energic", () -> new BlueCrystalEnergicBlock());
	public static final RegistryObject<Block> ACTIVED_ORANGE_CRYSTAL_ENERGIC = REGISTRY.register("actived_orange_crystal_energic", () -> new ActivedOrangeCrystalEnergicBlock());
	public static final RegistryObject<Block> ACTIVED_BLUE_CRYSTAL_ENERGIC = REGISTRY.register("actived_blue_crystal_energic", () -> new ActivedBlueCrystalEnergicBlock());
	public static final RegistryObject<Block> CAVE_STONE = REGISTRY.register("cave_stone", () -> new CaveStoneBlock());
	public static final RegistryObject<Block> CRYSTALIC_CAVE_STONE = REGISTRY.register("crystalic_cave_stone", () -> new CrystalicCaveStoneBlock());
	public static final RegistryObject<Block> CRYSTALIC_CAVE_STONE_ON = REGISTRY.register("crystalic_cave_stone_on", () -> new CrystalicCaveStoneOnBlock());
	public static final RegistryObject<Block> CUSTOM_CRYSTALIC_RECEIVER = REGISTRY.register("custom_crystalic_receiver", () -> new CustomCrystalicReceiverBlock());
	public static final RegistryObject<Block> ACTIVED_CUSTOM_CRYSTALIC_RECEIVER = REGISTRY.register("actived_custom_crystalic_receiver", () -> new ActivedCustomCrystalicReceiverBlock());
	public static final RegistryObject<Block> CUSTOM_CRYSTALIC_SENDER = REGISTRY.register("custom_crystalic_sender", () -> new CustomCrystalicSenderBlock());
	public static final RegistryObject<Block> DRAGON_IGNITER = REGISTRY.register("dragon_igniter", () -> new DragonIgniterBlock());
	public static final RegistryObject<Block> DRAGON_STEEL_BLOCK = REGISTRY.register("dragon_steel_block", () -> new DragonSteelBlockBlock());
	public static final RegistryObject<Block> CUT_DRAGON_STEEL_BLOCK = REGISTRY.register("cut_dragon_steel_block", () -> new CutDragonSteelBlockBlock());
	public static final RegistryObject<Block> DRAGON_STEEL_BARS = REGISTRY.register("dragon_steel_bars", () -> new DragonSteelBarsBlock());
	public static final RegistryObject<Block> DRAGON_STEEL_PILLARS = REGISTRY.register("dragon_steel_pillars", () -> new DragonSteelPillarsBlock());
	public static final RegistryObject<Block> ANDESITE_STONE_BRICKS = REGISTRY.register("andesite_stone_bricks", () -> new AndesiteStoneBricksBlock());
	public static final RegistryObject<Block> ANDESITE_STONE_PILLARS = REGISTRY.register("andesite_stone_pillars", () -> new AndesiteStonePillarsBlock());
	public static final RegistryObject<Block> CRACKED_ANDESITE_STONE_PILLARS = REGISTRY.register("cracked_andesite_stone_pillars", () -> new CrackedAndesiteStonePillarsBlock());
	public static final RegistryObject<Block> CRYSTALIC_TABLE = REGISTRY.register("crystalic_table", () -> new CrystalicTableBlock());
	public static final RegistryObject<Block> WET_MOSSY_STONE = REGISTRY.register("wet_mossy_stone", () -> new WetMossyStoneBlock());
	public static final RegistryObject<Block> WET_VINES = REGISTRY.register("wet_vines", () -> new WetVinesBlock());
	public static final RegistryObject<Block> LOST_LOOT_GENERATOR = REGISTRY.register("lost_loot_generator", () -> new LostLootGeneratorBlock());
	public static final RegistryObject<Block> DEAD_LIGHT = REGISTRY.register("dead_light", () -> new DeadLightBlock());
	public static final RegistryObject<Block> UNSTABLE_ROCK = REGISTRY.register("unstable_rock", () -> new UnstableRockBlock());
	public static final RegistryObject<Block> FALLING_UNSTABLE_ROCK = REGISTRY.register("falling_unstable_rock", () -> new FallingUnstableRockBlock());
	public static final RegistryObject<Block> RUSTY_BARS = REGISTRY.register("rusty_bars", () -> new RustyBarsBlock());
	public static final RegistryObject<Block> CRACKED_GLASS = REGISTRY.register("cracked_glass", () -> new CrackedGlassBlock());
	public static final RegistryObject<Block> METAL_BLOCK = REGISTRY.register("metal_block", () -> new MetalBlockBlock());
	public static final RegistryObject<Block> CORE_FRAME = REGISTRY.register("core_frame", () -> new CoreFrameBlock());
	public static final RegistryObject<Block> OLD_SYSTEM_CONTROLER = REGISTRY.register("old_system_controler", () -> new OldSystemControlerBlock());
	public static final RegistryObject<Block> MALFUNCTION_LAMP = REGISTRY.register("malfunction_lamp", () -> new MalfunctionLampBlock());
	public static final RegistryObject<Block> MALFUNCTION_LAMP_ON = REGISTRY.register("malfunction_lamp_on", () -> new MalfunctionLampOnBlock());
	public static final RegistryObject<Block> WET_CONCRETE = REGISTRY.register("wet_concrete", () -> new WetConcreteBlock());
	public static final RegistryObject<Block> GLASS_DOOR = REGISTRY.register("glass_door", () -> new GlassDoorBlock());
	public static final RegistryObject<Block> OPEN_GLASS_DOOR = REGISTRY.register("open_glass_door", () -> new OpenGlassDoorBlock());
	public static final RegistryObject<Block> SYSTEM_CONTROLLER_ON = REGISTRY.register("system_controller_on", () -> new SystemControllerOnBlock());
	public static final RegistryObject<Block> CORE_FRAME_INSERTED = REGISTRY.register("core_frame_inserted", () -> new CoreFrameInsertedBlock());
	public static final RegistryObject<Block> CAT_RUNE = REGISTRY.register("cat_rune", () -> new CatRuneBlock());
	public static final RegistryObject<Block> OLD_TECHNICAL_GLASS = REGISTRY.register("old_technical_glass", () -> new OldTechnicalGlassBlock());
	public static final RegistryObject<Block> TECHNICAL_GLASS_ON = REGISTRY.register("technical_glass_on", () -> new TechnicalGlassOnBlock());
	public static final RegistryObject<Block> TECHNICAL_GLASS_GLITCH = REGISTRY.register("technical_glass_glitch", () -> new TechnicalGlassGlitchBlock());
	public static final RegistryObject<Block> GEO_SENSOR = REGISTRY.register("geo_sensor", () -> new GeoSensorBlock());
	public static final RegistryObject<Block> GEO_SENSOR_ON = REGISTRY.register("geo_sensor_on", () -> new GeoSensorOnBlock());
	public static final RegistryObject<Block> DRAWERS = REGISTRY.register("drawers", () -> new DrawersBlock());
	public static final RegistryObject<Block> LOCKED_DRAWERS = REGISTRY.register("locked_drawers", () -> new LockedDrawersBlock());
	public static final RegistryObject<Block> EXPLORER_WORKSTATION = REGISTRY.register("explorer_workstation", () -> new ExplorerWorkstationBlock());
	public static final RegistryObject<Block> FIRST_TOWER_CORE = REGISTRY.register("first_tower_core", () -> new FirstTowerCoreBlock());
	public static final RegistryObject<Block> FIRST_TOWER_CORE_ON = REGISTRY.register("first_tower_core_on", () -> new FirstTowerCoreOnBlock());
	public static final RegistryObject<Block> MAGNETIC_ROCK = REGISTRY.register("magnetic_rock", () -> new MagneticRockBlock());
	public static final RegistryObject<Block> WEAK_MAGNETIC_ROCK = REGISTRY.register("weak_magnetic_rock", () -> new WeakMagneticRockBlock());
	public static final RegistryObject<Block> BROKEN_MAGNETIC_ROCK = REGISTRY.register("broken_magnetic_rock", () -> new BrokenMagneticRockBlock());
	public static final RegistryObject<Block> HARD_TREE_LOG = REGISTRY.register("hard_tree_log", () -> new HardTreeLogBlock());
	public static final RegistryObject<Block> HARD_TREE_LEAVES = REGISTRY.register("hard_tree_leaves", () -> new HardTreeLeavesBlock());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			WetVinesBlock.blockColorLoad(event);
			HardTreeLeavesBlock.blockColorLoad(event);
		}
	}
}
