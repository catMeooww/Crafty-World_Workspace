
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.extensions.IForgeMenuType;

import net.minecraft.world.inventory.MenuType;

import net.mcreator.utp.world.inventory.LootContainerMenu;
import net.mcreator.utp.world.inventory.CrystalicEditorMenu;
import net.mcreator.utp.UtpMod;

public class UtpModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.MENU_TYPES, UtpMod.MODID);
	public static final RegistryObject<MenuType<CrystalicEditorMenu>> CRYSTALIC_EDITOR = REGISTRY.register("crystalic_editor", () -> IForgeMenuType.create(CrystalicEditorMenu::new));
	public static final RegistryObject<MenuType<LootContainerMenu>> LOOT_CONTAINER = REGISTRY.register("loot_container", () -> IForgeMenuType.create(LootContainerMenu::new));
}
