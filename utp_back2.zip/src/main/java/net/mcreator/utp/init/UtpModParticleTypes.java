
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.utp.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.particles.ParticleType;

import net.mcreator.utp.UtpMod;

public class UtpModParticleTypes {
	public static final DeferredRegister<ParticleType<?>> REGISTRY = DeferredRegister.create(ForgeRegistries.PARTICLE_TYPES, UtpMod.MODID);
	public static final RegistryObject<SimpleParticleType> SMALL_MAGNETIC_ROCKS_PIECES = REGISTRY.register("small_magnetic_rocks_pieces", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> MAGNETIC_ROCKS_PIECES = REGISTRY.register("magnetic_rocks_pieces", () -> new SimpleParticleType(false));
	public static final RegistryObject<SimpleParticleType> LEAFNESS = REGISTRY.register("leafness", () -> new SimpleParticleType(false));
}
