
package net.mcreator.utp.block;

import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.core.BlockPos;

public class HardTreeLogBlock extends Block {
	public HardTreeLogBlock() {
		super(BlockBehaviour.Properties.of().sound(SoundType.STEM).strength(1.5f, 14f));
	}

	@Override
	public int getLightBlock(BlockState state, BlockGetter worldIn, BlockPos pos) {
		return 15;
	}
}
