package net.mcreator.utp.client.gui;

import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.gui.components.Checkbox;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.GuiGraphics;

import net.mcreator.utp.world.inventory.CrystalicEditorMenu;
import net.mcreator.utp.network.CrystalicEditorButtonMessage;
import net.mcreator.utp.UtpMod;

import java.util.HashMap;

import com.mojang.blaze3d.systems.RenderSystem;

public class CrystalicEditorScreen extends AbstractContainerScreen<CrystalicEditorMenu> {
	private final static HashMap<String, Object> guistate = CrystalicEditorMenu.guistate;
	private final Level world;
	private final int x, y, z;
	private final Player entity;
	Checkbox OrangeEnable;
	Checkbox BlueEnable;
	Button button_save;

	public CrystalicEditorScreen(CrystalicEditorMenu container, Inventory inventory, Component text) {
		super(container, inventory, text);
		this.world = container.world;
		this.x = container.x;
		this.y = container.y;
		this.z = container.z;
		this.entity = container.entity;
		this.imageWidth = 176;
		this.imageHeight = 166;
	}

	@Override
	public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTicks) {
		this.renderBackground(guiGraphics);
		super.render(guiGraphics, mouseX, mouseY, partialTicks);
		this.renderTooltip(guiGraphics, mouseX, mouseY);
	}

	@Override
	protected void renderBg(GuiGraphics guiGraphics, float partialTicks, int gx, int gy) {
		RenderSystem.setShaderColor(1, 1, 1, 1);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		guiGraphics.blit(new ResourceLocation("utp:textures/screens/orange_crystal.png"), this.leftPos + 42, this.topPos + 43, 0, 0, 16, 16, 16, 16);

		guiGraphics.blit(new ResourceLocation("utp:textures/screens/blue_crystal.png"), this.leftPos + 42, this.topPos + 79, 0, 0, 16, 16, 16, 16);

		RenderSystem.disableBlend();
	}

	@Override
	public boolean keyPressed(int key, int b, int c) {
		if (key == 256) {
			this.minecraft.player.closeContainer();
			return true;
		}
		return super.keyPressed(key, b, c);
	}

	@Override
	protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
		guiGraphics.drawString(this.font, Component.translatable("gui.utp.crystalic_editor.label_crystalic"), 33, 7, -39936, false);
		guiGraphics.drawString(this.font, Component.translatable("gui.utp.crystalic_editor.label_transmissor"), 87, 7, -7990542, false);
	}

	@Override
	public void init() {
		super.init();
		button_save = Button.builder(Component.translatable("gui.utp.crystalic_editor.button_save"), e -> {
			if (true) {
				UtpMod.PACKET_HANDLER.sendToServer(new CrystalicEditorButtonMessage(0, x, y, z));
				CrystalicEditorButtonMessage.handleButtonAction(entity, 0, x, y, z);
			}
		}).bounds(this.leftPos + 62, this.topPos + 115, 46, 20).build();
		guistate.put("button:button_save", button_save);
		this.addRenderableWidget(button_save);
		OrangeEnable = new Checkbox(this.leftPos + 114, this.topPos + 43, 20, 20, Component.translatable("gui.utp.crystalic_editor.OrangeEnable"), false);
		guistate.put("checkbox:OrangeEnable", OrangeEnable);
		this.addRenderableWidget(OrangeEnable);
		BlueEnable = new Checkbox(this.leftPos + 114, this.topPos + 79, 20, 20, Component.translatable("gui.utp.crystalic_editor.BlueEnable"), false);
		guistate.put("checkbox:BlueEnable", BlueEnable);
		this.addRenderableWidget(BlueEnable);
	}
}
