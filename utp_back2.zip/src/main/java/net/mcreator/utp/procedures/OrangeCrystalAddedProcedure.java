package net.mcreator.utp.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModBlocks;

import java.util.Map;

public class OrangeCrystalAddedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(BlockPos.containing(x + 1, y, z))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL.get()) {
			world.setBlock(BlockPos.containing(x + 1, y, z), UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get().defaultBlockState(), 3);
		}
		if ((world.getBlockState(BlockPos.containing(x - 1, y, z))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL.get()) {
			world.setBlock(BlockPos.containing(x - 1, y, z), UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get().defaultBlockState(), 3);
		}
		if ((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL.get()) {
			world.setBlock(BlockPos.containing(x, y + 1, z), UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get().defaultBlockState(), 3);
		}
		if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL.get()) {
			world.setBlock(BlockPos.containing(x, y - 1, z), UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get().defaultBlockState(), 3);
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z + 1))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL.get()) {
			world.setBlock(BlockPos.containing(x, y, z + 1), UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get().defaultBlockState(), 3);
		}
		if ((world.getBlockState(BlockPos.containing(x, y, z - 1))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL.get()) {
			world.setBlock(BlockPos.containing(x, y, z - 1), UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get().defaultBlockState(), 3);
		}
		if ((world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL_ENERGIC.get()) {
			{
				BlockPos _bp = BlockPos.containing(x, y + 1, z);
				BlockState _bs = UtpModBlocks.ACTIVED_ORANGE_CRYSTAL_ENERGIC.get().defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
		}
		if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL_ENERGIC.get()) {
			{
				BlockPos _bp = BlockPos.containing(x, y - 1, z);
				BlockState _bs = UtpModBlocks.ACTIVED_ORANGE_CRYSTAL_ENERGIC.get().defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
		}
	}
}
