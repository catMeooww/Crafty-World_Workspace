package net.mcreator.utp.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModBlocks;

import java.util.Map;

public class CrystalDisableProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get()) {
			world.setBlock(BlockPos.containing(x, y, z), UtpModBlocks.ORANGE_CRYSTAL.get().defaultBlockState(), 3);
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.ACTIVED_ORANGE_CRYSTAL_ENERGIC.get()) {
			{
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockState _bs = UtpModBlocks.ORANGE_CRYSTAL_ENERGIC.get().defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.ACTIVED_BLUE_CRYSTAL.get()) {
			world.setBlock(BlockPos.containing(x, y, z), UtpModBlocks.BLUE_CRYSTAL.get().defaultBlockState(), 3);
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.ACTIVED_BLUE_CRYSTAL_ENERGIC.get()) {
			{
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockState _bs = UtpModBlocks.BLUE_CRYSTAL_ENERGIC.get().defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
		}
	}
}
