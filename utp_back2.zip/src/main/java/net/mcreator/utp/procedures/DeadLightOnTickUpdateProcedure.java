package net.mcreator.utp.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

public class DeadLightOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double select_entity = 0;
		if (!(world instanceof Level _lvl0 && _lvl0.isDay())) {
			select_entity = Mth.nextInt(RandomSource.create(), 1, 4);
			if (select_entity == 1) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = EntityType.ZOMBIE.spawn(_level, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -3, 3), y + Mth.nextInt(RandomSource.create(), -3, 3), z + Mth.nextInt(RandomSource.create(), -3, 3)),
							MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
			} else if (select_entity == 2) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = EntityType.SKELETON.spawn(_level, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -3, 3), y + Mth.nextInt(RandomSource.create(), -3, 3), z + Mth.nextInt(RandomSource.create(), -3, 3)),
							MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
			} else if (select_entity == 3) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = EntityType.SPIDER.spawn(_level, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -3, 3), y + Mth.nextInt(RandomSource.create(), -3, 3), z + Mth.nextInt(RandomSource.create(), -3, 3)),
							MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
			}
		}
	}
}
