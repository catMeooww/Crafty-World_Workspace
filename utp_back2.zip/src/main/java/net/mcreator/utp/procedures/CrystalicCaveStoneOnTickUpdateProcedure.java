package net.mcreator.utp.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModBlocks;

import java.util.Map;

public class CrystalicCaveStoneOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(BlockPos.containing(x + 1, y, z))).getBlock() == UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get() || (world.getBlockState(BlockPos.containing(x + 1, y, z))).getBlock() == UtpModBlocks.ACTIVED_BLUE_CRYSTAL.get()
				|| (world.getBlockState(BlockPos.containing(x - 1, y, z))).getBlock() == UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get() || (world.getBlockState(BlockPos.containing(x - 1, y, z))).getBlock() == UtpModBlocks.ACTIVED_BLUE_CRYSTAL.get()
				|| (world.getBlockState(BlockPos.containing(x, y, z + 1))).getBlock() == UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get() || (world.getBlockState(BlockPos.containing(x, y, z + 1))).getBlock() == UtpModBlocks.ACTIVED_BLUE_CRYSTAL.get()
				|| (world.getBlockState(BlockPos.containing(x, y, z - 1))).getBlock() == UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get() || (world.getBlockState(BlockPos.containing(x, y, z - 1))).getBlock() == UtpModBlocks.ACTIVED_BLUE_CRYSTAL.get()) {
			{
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockState _bs = UtpModBlocks.CRYSTALIC_CAVE_STONE_ON.get().defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
		} else {
			{
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockState _bs = UtpModBlocks.CRYSTALIC_CAVE_STONE.get().defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
		}
	}
}
