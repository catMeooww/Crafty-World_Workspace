package net.mcreator.utp.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModBlocks;

public class UnstableRockPlayerStartsToDestroyProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!entity.isShiftKeyDown()) {
			world.setBlock(BlockPos.containing(x, y, z), UtpModBlocks.FALLING_UNSTABLE_ROCK.get().defaultBlockState(), 3);
		}
	}
}
