package net.mcreator.utp.procedures;

import net.minecraft.world.entity.Entity;

public class DragonFireEntityCollidesInTheBlockProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if (!entity.isShiftKeyDown()) {
			entity.setSecondsOnFire(6);
		}
	}
}
