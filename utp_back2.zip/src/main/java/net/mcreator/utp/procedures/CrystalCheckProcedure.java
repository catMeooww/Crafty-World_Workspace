package net.mcreator.utp.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModBlocks;

public class CrystalCheckProcedure {
	public static boolean execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL.get() || (world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == UtpModBlocks.BLUE_CRYSTAL.get()
				|| (world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL.get() || (world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == UtpModBlocks.BLUE_CRYSTAL.get()
				|| (world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get() || (world.getBlockState(BlockPos.containing(x, y - 1, z))).getBlock() == UtpModBlocks.ACTIVED_BLUE_CRYSTAL.get()
				|| (world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get() || (world.getBlockState(BlockPos.containing(x, y + 1, z))).getBlock() == UtpModBlocks.ACTIVED_BLUE_CRYSTAL.get()) {
			return true;
		}
		return false;
	}
}
