package net.mcreator.utp.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModGameRules;
import net.mcreator.utp.init.UtpModBlocks;

import java.util.Map;

public class CustomCrystalEnergicOffProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double tryX = 0;
		double tryY = 0;
		double tryZ = 0;
		if (world instanceof ServerLevel _level)
			_level.sendParticles(ParticleTypes.ASH, (x + tryX), (y + tryY), (z + tryZ), 3, 1, 1, 1, 1);
		tryX = (world.getLevelData().getGameRules().getInt(UtpModGameRules.CRYSTAL_RANGE));
		for (int index0 = 0; index0 < (int) ((world.getLevelData().getGameRules().getInt(UtpModGameRules.CRYSTAL_RANGE)) * 2 + 1); index0++) {
			tryY = (world.getLevelData().getGameRules().getInt(UtpModGameRules.CRYSTAL_RANGE));
			for (int index1 = 0; index1 < (int) ((world.getLevelData().getGameRules().getInt(UtpModGameRules.CRYSTAL_RANGE)) * 2); index1++) {
				tryZ = (world.getLevelData().getGameRules().getInt(UtpModGameRules.CRYSTAL_RANGE));
				for (int index2 = 0; index2 < (int) ((world.getLevelData().getGameRules().getInt(UtpModGameRules.CRYSTAL_RANGE)) * 2 + 1); index2++) {
					if ((world.getBlockState(BlockPos.containing(x + tryX, y + tryY, z + tryZ))).getBlock() == UtpModBlocks.ACTIVED_CUSTOM_CRYSTALIC_RECEIVER.get() && ((new Object() {
						public boolean getValue(LevelAccessor world, BlockPos pos, String tag) {
							BlockEntity blockEntity = world.getBlockEntity(pos);
							if (blockEntity != null)
								return blockEntity.getPersistentData().getBoolean(tag);
							return false;
						}
					}.getValue(world, BlockPos.containing(x + tryX, y + tryY, z + tryZ), "crystalicOrange")) == (new Object() {
						public boolean getValue(LevelAccessor world, BlockPos pos, String tag) {
							BlockEntity blockEntity = world.getBlockEntity(pos);
							if (blockEntity != null)
								return blockEntity.getPersistentData().getBoolean(tag);
							return false;
						}
					}.getValue(world, BlockPos.containing(x, y, z), "crystalicOrange")) || (new Object() {
						public boolean getValue(LevelAccessor world, BlockPos pos, String tag) {
							BlockEntity blockEntity = world.getBlockEntity(pos);
							if (blockEntity != null)
								return blockEntity.getPersistentData().getBoolean(tag);
							return false;
						}
					}.getValue(world, BlockPos.containing(x + tryX, y + tryY, z + tryZ), "crystalicBlue")) == (new Object() {
						public boolean getValue(LevelAccessor world, BlockPos pos, String tag) {
							BlockEntity blockEntity = world.getBlockEntity(pos);
							if (blockEntity != null)
								return blockEntity.getPersistentData().getBoolean(tag);
							return false;
						}
					}.getValue(world, BlockPos.containing(x, y, z), "crystalicBlue")))) {
						{
							BlockPos _bp = BlockPos.containing(x + tryX, y + tryY, z + tryZ);
							BlockState _bs = UtpModBlocks.CUSTOM_CRYSTALIC_RECEIVER.get().defaultBlockState();
							BlockState _bso = world.getBlockState(_bp);
							for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
								Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
								if (_property != null && _bs.getValue(_property) != null)
									try {
										_bs = _bs.setValue(_property, (Comparable) entry.getValue());
									} catch (Exception e) {
									}
							}
							BlockEntity _be = world.getBlockEntity(_bp);
							CompoundTag _bnbt = null;
							if (_be != null) {
								_bnbt = _be.saveWithFullMetadata();
								_be.setRemoved();
							}
							world.setBlock(_bp, _bs, 3);
							if (_bnbt != null) {
								_be = world.getBlockEntity(_bp);
								if (_be != null) {
									try {
										_be.load(_bnbt);
									} catch (Exception ignored) {
									}
								}
							}
						}
						if (world instanceof ServerLevel _level)
							_level.sendParticles(ParticleTypes.ASH, (x + tryX), (y + tryY), (z + tryZ), 3, 1, 1, 1, 1);
					}
					tryZ = tryZ - 1;
				}
				tryY = tryY - 1;
			}
			tryX = tryX - 1;
		}
	}
}
