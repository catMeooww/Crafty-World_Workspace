package net.mcreator.utp.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModBlocks;

public class CrystalOnActiveProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (!entity.isShiftKeyDown()) {
			if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.ORANGE_CRYSTAL.get()) {
				world.setBlock(BlockPos.containing(x, y, z), UtpModBlocks.ACTIVED_ORANGE_CRYSTAL.get().defaultBlockState(), 3);
			} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.BLUE_CRYSTAL.get()) {
				world.setBlock(BlockPos.containing(x, y, z), UtpModBlocks.ACTIVED_BLUE_CRYSTAL.get().defaultBlockState(), 3);
			}
		}
	}
}
