package net.mcreator.utp.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

public class DragonDoorOnBlockRightClickedProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double posZ = 0;
		if (new Object() {
			public boolean getValue(LevelAccessor world, BlockPos pos, String tag) {
				BlockEntity blockEntity = world.getBlockEntity(pos);
				if (blockEntity != null)
					return blockEntity.getPersistentData().getBoolean(tag);
				return false;
			}
		}.getValue(world, BlockPos.containing(x, y, z), "hasKey")) {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.chain.step")), SoundSource.BLOCKS, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.chain.step")), SoundSource.BLOCKS, 1, 1, false);
				}
			}
		} else {
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.stone.break")), SoundSource.BLOCKS, 1, 1);
				} else {
					_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.stone.break")), SoundSource.BLOCKS, 1, 1, false);
				}
			}
			posZ = -1;
			for (int index0 = 0; index0 < 3; index0++) {
				world.setBlock(BlockPos.containing(x, y, z + posZ), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(BlockPos.containing(x + 1, y, z + posZ), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(BlockPos.containing(x - 1, y, z + posZ), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(BlockPos.containing(x, y + 1, z + posZ), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(BlockPos.containing(x, y - 1, z + posZ), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(BlockPos.containing(x + 1, y + 1, z + posZ), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(BlockPos.containing(x + 1, y - 1, z + posZ), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(BlockPos.containing(x - 1, y + 1, z + posZ), Blocks.AIR.defaultBlockState(), 3);
				world.setBlock(BlockPos.containing(x - 1, y - 1, z + posZ), Blocks.AIR.defaultBlockState(), 3);
				posZ = posZ + 1;
			}
		}
	}
}
