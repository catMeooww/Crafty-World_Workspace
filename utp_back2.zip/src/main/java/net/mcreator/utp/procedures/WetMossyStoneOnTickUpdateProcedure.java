package net.mcreator.utp.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModBlocks;

public class WetMossyStoneOnTickUpdateProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.WET_MOSSY_STONE.get()) {
			if (!world.getBlockState(BlockPos.containing(x + 1, y, z)).canOcclude()) {
				world.setBlock(BlockPos.containing(x + 1, y, z), UtpModBlocks.WET_VINES.get().defaultBlockState(), 3);
			}
			if (!world.getBlockState(BlockPos.containing(x - 1, y, z)).canOcclude()) {
				world.setBlock(BlockPos.containing(x - 1, y, z), UtpModBlocks.WET_VINES.get().defaultBlockState(), 3);
				if (!world.getBlockState(BlockPos.containing(x, y, z + 1)).canOcclude()) {
					world.setBlock(BlockPos.containing(x, y, z + 1), UtpModBlocks.WET_VINES.get().defaultBlockState(), 3);
				}
				if (!world.getBlockState(BlockPos.containing(x, y, z - 1)).canOcclude()) {
					world.setBlock(BlockPos.containing(x, y, z - 1), UtpModBlocks.WET_VINES.get().defaultBlockState(), 3);
				}
			}
		}
		if (!world.getBlockState(BlockPos.containing(x, y - 1, z)).canOcclude()) {
			world.setBlock(BlockPos.containing(x, y - 1, z), UtpModBlocks.WET_VINES.get().defaultBlockState(), 3);
		}
	}
}
