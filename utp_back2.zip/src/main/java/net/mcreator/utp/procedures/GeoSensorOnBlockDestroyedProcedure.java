package net.mcreator.utp.procedures;

import net.minecraft.world.level.LevelAccessor;

import net.mcreator.utp.network.UtpModVariables;

public class GeoSensorOnBlockDestroyedProcedure {
	public static void execute(LevelAccessor world) {
		UtpModVariables.MapVariables.get(world).global_sensor = UtpModVariables.MapVariables.get(world).global_sensor - 1;
		UtpModVariables.MapVariables.get(world).syncData(world);
	}
}
