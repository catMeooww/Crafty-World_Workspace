package net.mcreator.utp.procedures;

import net.minecraftforge.registries.ForgeRegistries;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModBlocks;

import java.util.Map;

public class SystemControlerActiveProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double testX = 0;
		double testY = 0;
		double testZ = 0;
		double located = 0;
		located = 0;
		testX = 20;
		for (int index0 = 0; index0 < (int) (20 * 2 + 1); index0++) {
			testY = 20;
			for (int index1 = 0; index1 < (int) (20 * 2 + 1); index1++) {
				testZ = 20;
				for (int index2 = 0; index2 < (int) (20 * 2 + 1); index2++) {
					if ((world.getBlockState(BlockPos.containing(x + testX, y + testY, z + testZ))).getBlock() == UtpModBlocks.CORE_FRAME_INSERTED.get()) {
						located = located + 1;
					}
					testZ = testZ - 1;
				}
				testY = testY - 1;
			}
			testX = testX - 1;
		}
		if (located >= 4) {
			{
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockState _bs = UtpModBlocks.SYSTEM_CONTROLLER_ON.get().defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
			if (world instanceof Level _level) {
				if (!_level.isClientSide()) {
					_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.resonate")), SoundSource.BLOCKS, (float) 0.5, (float) 1.2);
				} else {
					_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.amethyst_block.resonate")), SoundSource.BLOCKS, (float) 0.5, (float) 1.2, false);
				}
			}
		}
	}
}
