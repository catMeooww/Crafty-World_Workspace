package net.mcreator.utp.procedures;

import net.minecraftforge.items.IItemHandlerModifiable;
import net.minecraftforge.common.capabilities.ForgeCapabilities;

import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.init.UtpModItems;
import net.mcreator.utp.init.UtpModBlocks;

public class LootGeneratorGeneratesProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double loot = 0;
		double loop = 0;
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.DRAGON_LOOT_GENERATOR.get()) {
			loop = Mth.nextInt(RandomSource.create(), 0, 5);
			for (int index0 = 0; index0 < Mth.nextInt(RandomSource.create(), 1, 7); index0++) {
				loot = Mth.nextInt(RandomSource.create(), 1, 5);
				if (loot == 1) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.DIAMOND).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 2) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(UtpModBlocks.DRAGON_WOOD_LOG.get()).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 3) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Blocks.OBSIDIAN).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 4) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.IRON_INGOT).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 5) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.CHARCOAL).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				}
				loop = loop + Mth.nextInt(RandomSource.create(), 1, 5);
			}
			world.setBlock(BlockPos.containing(x, y, z), UtpModBlocks.DRAGON_BRICKS.get().defaultBlockState(), 3);
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.DUNGEON_LOOT_GENERATOR.get()) {
			loop = Mth.nextInt(RandomSource.create(), 0, 5);
			for (int index1 = 0; index1 < Mth.nextInt(RandomSource.create(), 1, 7); index1++) {
				loot = Mth.nextInt(RandomSource.create(), 1, 10);
				if (loot == 1) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.NAME_TAG).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 2) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.GUNPOWDER).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 3) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.STRING).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 4) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.SADDLE).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 5) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.BONE_MEAL).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 10) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(UtpModItems.SPAWN_POWDER.get()).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Blocks.VINE).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				}
				loop = loop + Mth.nextInt(RandomSource.create(), 1, 5);
			}
			world.setBlock(BlockPos.containing(x, y, z), Blocks.COBBLESTONE.defaultBlockState(), 3);
		} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.LOST_LOOT_GENERATOR.get()) {
			loop = Mth.nextInt(RandomSource.create(), 0, 5);
			for (int index2 = 0; index2 < Mth.nextInt(RandomSource.create(), 1, 7); index2++) {
				loot = Mth.nextInt(RandomSource.create(), 1, 10);
				if (loot == 1) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.NAME_TAG).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 2) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.IRON_INGOT).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 3) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(UtpModBlocks.ANDESITE_STONE_PILLARS.get()).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 4) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.SADDLE).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 5) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.BONE_MEAL).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else if (loot == 10) {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Items.REDSTONE).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				} else {
					{
						BlockEntity _ent = world.getBlockEntity(BlockPos.containing(x, y + 1, z));
						if (_ent != null) {
							final int _slotid = (int) loop;
							final ItemStack _setstack = new ItemStack(Blocks.VINE).copy();
							_setstack.setCount(1);
							_ent.getCapability(ForgeCapabilities.ITEM_HANDLER, null).ifPresent(capability -> {
								if (capability instanceof IItemHandlerModifiable)
									((IItemHandlerModifiable) capability).setStackInSlot(_slotid, _setstack);
							});
						}
					}
				}
				loop = loop + Mth.nextInt(RandomSource.create(), 1, 5);
			}
			world.setBlock(BlockPos.containing(x, y, z), Blocks.STONE_BRICKS.defaultBlockState(), 3);
		}
		if (world instanceof ServerLevel _level)
			_level.sendParticles(ParticleTypes.ASH, x, y, z, 5, 1, 1, 1, 1);
	}
}
