package net.mcreator.utp.procedures;

import net.minecraft.world.level.block.state.properties.Property;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.BlockPos;

import net.mcreator.utp.network.UtpModVariables;
import net.mcreator.utp.init.UtpModItems;
import net.mcreator.utp.init.UtpModBlocks;

import java.util.Map;

public class TowerCoresRemoveProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == UtpModBlocks.FIRST_TOWER_CORE_ON.get()) {
			UtpModVariables.MapVariables.get(world).first_tower_active = false;
			UtpModVariables.MapVariables.get(world).syncData(world);
			{
				BlockPos _bp = BlockPos.containing(x, y, z);
				BlockState _bs = UtpModBlocks.FIRST_TOWER_CORE.get().defaultBlockState();
				BlockState _bso = world.getBlockState(_bp);
				for (Map.Entry<Property<?>, Comparable<?>> entry : _bso.getValues().entrySet()) {
					Property _property = _bs.getBlock().getStateDefinition().getProperty(entry.getKey().getName());
					if (_property != null && _bs.getValue(_property) != null)
						try {
							_bs = _bs.setValue(_property, (Comparable) entry.getValue());
						} catch (Exception e) {
						}
				}
				world.setBlock(_bp, _bs, 3);
			}
			if (world instanceof ServerLevel _level) {
				ItemEntity entityToSpawn = new ItemEntity(_level, x, y, z, new ItemStack(UtpModItems.ENERGY_CORE.get()));
				entityToSpawn.setPickUpDelay(10);
				_level.addFreshEntity(entityToSpawn);
			}
		}
	}
}
