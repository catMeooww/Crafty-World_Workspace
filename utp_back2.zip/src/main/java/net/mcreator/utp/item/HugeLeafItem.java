
package net.mcreator.utp.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class HugeLeafItem extends Item {
	public HugeLeafItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
