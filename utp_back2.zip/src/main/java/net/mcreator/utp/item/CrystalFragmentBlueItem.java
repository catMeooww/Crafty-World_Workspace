
package net.mcreator.utp.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class CrystalFragmentBlueItem extends Item {
	public CrystalFragmentBlueItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
