
package net.mcreator.utp.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class DrawerKeyItem extends Item {
	public DrawerKeyItem() {
		super(new Item.Properties().stacksTo(1).rarity(Rarity.COMMON));
	}
}
