
package net.mcreator.utp.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SolidFlameItem extends Item {
	public SolidFlameItem() {
		super(new Item.Properties().stacksTo(64).rarity(Rarity.COMMON));
	}
}
