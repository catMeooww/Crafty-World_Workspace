package net.mcreator.landofislands.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;

import net.mcreator.landofislands.init.LandOfIslandsModBlocks;

public class FloatiteCoringProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		double coreselect = 0;
		coreselect = Mth.nextInt(RandomSource.create(), 1, 1);
		if (coreselect == 1) {
			if (world instanceof ServerLevel _level)
				_level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, x, y, z, 5, 1, 1, 1, 0.3);
			world.setBlock(BlockPos.containing(x, y, z), LandOfIslandsModBlocks.FLOATITE_CORE_I_1.get().defaultBlockState(), 3);
		}
	}
}
