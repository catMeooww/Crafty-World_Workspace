package net.mcreator.landofislands.procedures;

import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.util.RandomSource;
import net.minecraft.util.Mth;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.landofislands.init.LandOfIslandsModBlocks;

public class IslandExtendingProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		double selectedIsland = 0;
		if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getCount() > 5 && (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getCount() <= 10) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.DIRT.asItem()) {
				selectedIsland = Mth.nextInt(RandomSource.create(), 1, 3);
				if (selectedIsland == 1) {
					if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "tiny_island"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "tiny_island"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 14, 21)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 14, 21)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
				} else if (selectedIsland == 2) {
					if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "tiny_island_2"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "tiny_island_2"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 14, 21)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 14, 21)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
				} else {
					if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "tiny_island_3"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "tiny_island_3"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 14, 21)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 14, 21)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
				}
			}
		} else if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getCount() > 10 && (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getCount() <= 20) {
			if ((entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.DIRT.asItem()
					|| (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.OAK_PLANKS.asItem()
					|| (entity instanceof LivingEntity _livEnt ? _livEnt.getMainHandItem() : ItemStack.EMPTY).getItem() == Blocks.SPRUCE_PLANKS.asItem()) {
				selectedIsland = Mth.nextInt(RandomSource.create(), 1, 5);
				if (selectedIsland == 1) {
					if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
				} else if (selectedIsland == 2) {
					if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island_2"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island_2"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
				} else if (selectedIsland == 3) {
					if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island_3"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island_3"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
				} else if (selectedIsland == 4) {
					if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island_frost"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island_frost"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
				} else {
					if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island_sjungle"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z + Mth.nextInt(RandomSource.create(), 8, 16)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					} else if ((world.getBlockState(BlockPos.containing(x, y, z))).getBlock() == LandOfIslandsModBlocks.ISLAND_EXTENDER.get()) {
						if (world instanceof ServerLevel _serverworld) {
							StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "small_island_sjungle"));
							if (template != null) {
								template.placeInWorld(_serverworld, BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										BlockPos.containing(x + Mth.nextInt(RandomSource.create(), -10, 10), y + Mth.nextInt(RandomSource.create(), -10, 10), z - Mth.nextInt(RandomSource.create(), 20, 27)),
										new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
							}
						}
					}
				}
			}
		}
	}
}
