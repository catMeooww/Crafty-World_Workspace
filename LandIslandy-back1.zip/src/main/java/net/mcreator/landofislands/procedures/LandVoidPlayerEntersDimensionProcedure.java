package net.mcreator.landofislands.procedures;

import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructurePlaceSettings;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.Mirror;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.landofislands.network.LandOfIslandsModVariables;

public class LandVoidPlayerEntersDimensionProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (!LandOfIslandsModVariables.WorldVariables.get(world).LandVoidPrepared) {
			if (world instanceof ServerLevel _serverworld) {
				StructureTemplate template = _serverworld.getStructureManager().getOrCreate(new ResourceLocation("land_of_islands", "spawn_island"));
				if (template != null) {
					template.placeInWorld(_serverworld, new BlockPos(-7, 100, -7), new BlockPos(-7, 100, -7), new StructurePlaceSettings().setRotation(Rotation.NONE).setMirror(Mirror.NONE).setIgnoreEntities(false), _serverworld.random, 3);
				}
			}
			LandOfIslandsModVariables.WorldVariables.get(world).LandVoidPrepared = true;
			LandOfIslandsModVariables.WorldVariables.get(world).syncData(world);
		}
		{
			Entity _ent = entity;
			_ent.teleportTo(0, 110, 0);
			if (_ent instanceof ServerPlayer _serverPlayer)
				_serverPlayer.connection.teleport(0, 110, 0, _ent.getYRot(), _ent.getXRot());
		}
	}
}
