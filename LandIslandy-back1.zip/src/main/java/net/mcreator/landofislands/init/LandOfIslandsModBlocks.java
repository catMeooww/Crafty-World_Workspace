
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.landofislands.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.landofislands.block.SkytzPortalBlock;
import net.mcreator.landofislands.block.SkytzPillarTopBlock;
import net.mcreator.landofislands.block.SkytzPillarBlock;
import net.mcreator.landofislands.block.SkytzFlowingBlock;
import net.mcreator.landofislands.block.SkytzChiseledBlock;
import net.mcreator.landofislands.block.SkytzBlockBlock;
import net.mcreator.landofislands.block.SkyLightBlock;
import net.mcreator.landofislands.block.SkyGlassLightBlock;
import net.mcreator.landofislands.block.OverworldPortalBlock;
import net.mcreator.landofislands.block.MutableSkytzBlockBlock;
import net.mcreator.landofislands.block.MagneticFieldGeneratorBlock;
import net.mcreator.landofislands.block.LessIslandExtenderBlock;
import net.mcreator.landofislands.block.IslandyAirBlock;
import net.mcreator.landofislands.block.IslandExtenderBlock;
import net.mcreator.landofislands.block.IslandElevatorBlock;
import net.mcreator.landofislands.block.FloatiteCoreI1Block;
import net.mcreator.landofislands.block.FloatiteCoreGenBlock;
import net.mcreator.landofislands.LandOfIslandsMod;

public class LandOfIslandsModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, LandOfIslandsMod.MODID);
	public static final RegistryObject<Block> ISLAND_ELEVATOR = REGISTRY.register("island_elevator", () -> new IslandElevatorBlock());
	public static final RegistryObject<Block> ISLAND_EXTENDER = REGISTRY.register("island_extender", () -> new IslandExtenderBlock());
	public static final RegistryObject<Block> LESS_ISLAND_EXTENDER = REGISTRY.register("less_island_extender", () -> new LessIslandExtenderBlock());
	public static final RegistryObject<Block> MAGNETIC_FIELD_GENERATOR = REGISTRY.register("magnetic_field_generator", () -> new MagneticFieldGeneratorBlock());
	public static final RegistryObject<Block> SKYTZ_BLOCK = REGISTRY.register("skytz_block", () -> new SkytzBlockBlock());
	public static final RegistryObject<Block> SKYTZ_PILLAR = REGISTRY.register("skytz_pillar", () -> new SkytzPillarBlock());
	public static final RegistryObject<Block> SKYTZ_PILLAR_TOP = REGISTRY.register("skytz_pillar_top", () -> new SkytzPillarTopBlock());
	public static final RegistryObject<Block> SKYTZ_CHISELED = REGISTRY.register("skytz_chiseled", () -> new SkytzChiseledBlock());
	public static final RegistryObject<Block> SKYTZ_FLOWING = REGISTRY.register("skytz_flowing", () -> new SkytzFlowingBlock());
	public static final RegistryObject<Block> SKYTZ_PORTAL = REGISTRY.register("skytz_portal", () -> new SkytzPortalBlock());
	public static final RegistryObject<Block> SKY_LIGHT = REGISTRY.register("sky_light", () -> new SkyLightBlock());
	public static final RegistryObject<Block> SKY_GLASS_LIGHT = REGISTRY.register("sky_glass_light", () -> new SkyGlassLightBlock());
	public static final RegistryObject<Block> MUTABLE_SKYTZ_BLOCK = REGISTRY.register("mutable_skytz_block", () -> new MutableSkytzBlockBlock());
	public static final RegistryObject<Block> FLOATITE_CORE_I_1 = REGISTRY.register("floatite_core_i_1", () -> new FloatiteCoreI1Block());
	public static final RegistryObject<Block> FLOATITE_CORE_GEN = REGISTRY.register("floatite_core_gen", () -> new FloatiteCoreGenBlock());
	public static final RegistryObject<Block> OVERWORLD_PORTAL = REGISTRY.register("overworld_portal", () -> new OverworldPortalBlock());
	public static final RegistryObject<Block> ISLANDY_AIR = REGISTRY.register("islandy_air", () -> new IslandyAirBlock());

	// Start of user code block custom blocks
	// End of user code block custom blocks
	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class BlocksClientSideHandler {
		@SubscribeEvent
		public static void blockColorLoad(RegisterColorHandlersEvent.Block event) {
			SkytzPortalBlock.blockColorLoad(event);
			MutableSkytzBlockBlock.blockColorLoad(event);
		}

		@SubscribeEvent
		public static void itemColorLoad(RegisterColorHandlersEvent.Item event) {
			SkytzPortalBlock.itemColorLoad(event);
		}
	}
}
