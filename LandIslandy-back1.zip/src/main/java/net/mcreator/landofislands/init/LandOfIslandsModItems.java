
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.landofislands.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.landofislands.item.ItemCore1Item;
import net.mcreator.landofislands.item.IslandGeneratorTinyItem;
import net.mcreator.landofislands.item.IslandGeneratorSmallItem;
import net.mcreator.landofislands.item.IslandGeneratorPlatformItem;
import net.mcreator.landofislands.LandOfIslandsMod;

public class LandOfIslandsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, LandOfIslandsMod.MODID);
	public static final RegistryObject<Item> ISLAND_ELEVATOR = block(LandOfIslandsModBlocks.ISLAND_ELEVATOR);
	public static final RegistryObject<Item> ISLAND_GENERATOR_TINY = REGISTRY.register("island_generator_tiny", () -> new IslandGeneratorTinyItem());
	public static final RegistryObject<Item> ISLAND_EXTENDER = block(LandOfIslandsModBlocks.ISLAND_EXTENDER);
	public static final RegistryObject<Item> LESS_ISLAND_EXTENDER = block(LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER);
	public static final RegistryObject<Item> ISLAND_GENERATOR_SMALL = REGISTRY.register("island_generator_small", () -> new IslandGeneratorSmallItem());
	public static final RegistryObject<Item> MAGNETIC_FIELD_GENERATOR = block(LandOfIslandsModBlocks.MAGNETIC_FIELD_GENERATOR);
	public static final RegistryObject<Item> ISLAND_GENERATOR_PLATFORM = REGISTRY.register("island_generator_platform", () -> new IslandGeneratorPlatformItem());
	public static final RegistryObject<Item> SKYTZ_BLOCK = block(LandOfIslandsModBlocks.SKYTZ_BLOCK);
	public static final RegistryObject<Item> SKYTZ_PILLAR = block(LandOfIslandsModBlocks.SKYTZ_PILLAR);
	public static final RegistryObject<Item> SKYTZ_PILLAR_TOP = block(LandOfIslandsModBlocks.SKYTZ_PILLAR_TOP);
	public static final RegistryObject<Item> SKYTZ_CHISELED = block(LandOfIslandsModBlocks.SKYTZ_CHISELED);
	public static final RegistryObject<Item> SKYTZ_FLOWING = block(LandOfIslandsModBlocks.SKYTZ_FLOWING);
	public static final RegistryObject<Item> SKYTZ_PORTAL = block(LandOfIslandsModBlocks.SKYTZ_PORTAL);
	public static final RegistryObject<Item> SKY_LIGHT = block(LandOfIslandsModBlocks.SKY_LIGHT);
	public static final RegistryObject<Item> SKY_GLASS_LIGHT = block(LandOfIslandsModBlocks.SKY_GLASS_LIGHT);
	public static final RegistryObject<Item> MUTABLE_SKYTZ_BLOCK = block(LandOfIslandsModBlocks.MUTABLE_SKYTZ_BLOCK);
	public static final RegistryObject<Item> FLOATITE_CORE_I_1 = block(LandOfIslandsModBlocks.FLOATITE_CORE_I_1);
	public static final RegistryObject<Item> FLOATITE_CORE_GEN = block(LandOfIslandsModBlocks.FLOATITE_CORE_GEN);
	public static final RegistryObject<Item> OVERWORLD_PORTAL = block(LandOfIslandsModBlocks.OVERWORLD_PORTAL);
	public static final RegistryObject<Item> ITEM_CORE_1 = REGISTRY.register("item_core_1", () -> new ItemCore1Item());
	public static final RegistryObject<Item> ISLANDY_AIR = block(LandOfIslandsModBlocks.ISLANDY_AIR);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
