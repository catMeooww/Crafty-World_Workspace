
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.landofislands.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.landofislands.LandOfIslandsMod;

public class LandOfIslandsModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LandOfIslandsMod.MODID);
	public static final RegistryObject<CreativeModeTab> ISLAND_GEN = REGISTRY.register("island_gen",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.land_of_islands.island_gen")).icon(() -> new ItemStack(LandOfIslandsModItems.ISLAND_GENERATOR_TINY.get())).displayItems((parameters, tabData) -> {
				tabData.accept(LandOfIslandsModBlocks.ISLAND_EXTENDER.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.LESS_ISLAND_EXTENDER.get().asItem());
				tabData.accept(LandOfIslandsModItems.ISLAND_GENERATOR_TINY.get());
				tabData.accept(LandOfIslandsModItems.ISLAND_GENERATOR_SMALL.get());
				tabData.accept(LandOfIslandsModBlocks.MAGNETIC_FIELD_GENERATOR.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.ISLAND_ELEVATOR.get().asItem());
				tabData.accept(LandOfIslandsModItems.ISLAND_GENERATOR_PLATFORM.get());
				tabData.accept(LandOfIslandsModBlocks.SKYTZ_BLOCK.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.SKYTZ_PILLAR.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.SKYTZ_PILLAR_TOP.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.SKYTZ_CHISELED.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.SKYTZ_FLOWING.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.SKYTZ_PORTAL.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.SKY_LIGHT.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.SKY_GLASS_LIGHT.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.FLOATITE_CORE_I_1.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.FLOATITE_CORE_GEN.get().asItem());
				tabData.accept(LandOfIslandsModBlocks.OVERWORLD_PORTAL.get().asItem());
				tabData.accept(LandOfIslandsModItems.ITEM_CORE_1.get());
			}).build());
}
